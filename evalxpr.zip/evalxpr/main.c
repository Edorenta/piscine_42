#include <stdlib.h>
#include "libft.h"

int main(int ac, char **av)
{
    int res;
    char *tmp;

    if (ac != 2)
        return (0);
    tmp = malloc(sizeof(tmp) * (ft_strlen(av[1]) + 1)); // PROTECT
    tmp = infix_to_postfix(av[1]);
//   reparse(tmp);
    ft_putstr(tmp);
    ft_putchar('\n');
    res = postfix_to_int(tmp);
    ft_putnbr(res);
    return (res);
}

